import sqlite3
from datetime import datetime, timedelta
from functools import wraps
from flask import Flask, render_template, request, redirect, session, jsonify, flash, url_for
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__); app.secret_key = "canteen-demo-key"
DB = "canteen.db"

# ───────── Database helpers + seed ─────────
def q(sql, a=(), one=False, commit=False):
    c = sqlite3.connect(DB); c.row_factory = sqlite3.Row
    r = c.execute(sql, a)
    if commit: c.commit(); lid = r.lastrowid; c.close(); return lid
    rows = r.fetchall(); c.close()
    return (rows[0] if rows else None) if one else rows

def init_db():
    c = sqlite3.connect(DB)
    c.executescript("""
    create table if not exists users(id integer primary key, name, email unique, pw, role);
    create table if not exists items(id integer primary key, name, price real, stock int, prep int, emoji, active int default 1);
    create table if not exists orders(id integer primary key, token int, user_id int, slot, day, total real, method, paid int, status default 'Pending', created);
    create table if not exists order_items(order_id int, item_id int, qty int);
    create table if not exists settings(k primary key, v);""")
    if not c.execute("select 1 from users").fetchone():
        for n, e, p, r in [("Admin","admin@c.com","admin","admin"),("Chef","kitchen@c.com","kitchen","kitchen"),
                           ("Asha (Student)","student@c.com","student","student"),("Ravi (Staff)","staff@c.com","staff","staff")]:
            c.execute("insert into users(name,email,pw,role) values(?,?,?,?)", (n, e, generate_password_hash(p), r))
        for n, p, s, t, e in [("Masala Dosa",60,30,6,"🥞"),("Veg Biryani",90,25,8,"🍛"),("Samosa (2 pcs)",30,50,2,"🥟"),
                              ("Veg Sandwich",45,40,4,"🥪"),("Filter Coffee",20,60,1,"☕"),("Fresh Lime Soda",25,40,1,"🍋"),
                              ("Chole Bhature",70,20,7,"🫓"),("Gulab Jamun",30,35,1,"🍮")]:
            c.execute("insert into items(name,price,stock,prep,emoji) values(?,?,?,?,?)", (n, p, s, t, e))
        c.execute("insert into settings values('cap','20')")
    c.commit(); c.close()

# ───────── Module 1: User Authentication ─────────
def login_required(*roles):
    def deco(f):
        @wraps(f)
        def w(*a, **k):
            if "uid" not in session: return redirect(url_for("login"))
            if roles and session["role"] not in roles:
                flash("You don't have access to that page.", "err"); return redirect("/")
            return f(*a, **k)
        return w
    return deco

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = q("select * from users where email=?", (request.form["email"].strip().lower(),), one=True)
        if u and check_password_hash(u["pw"], request.form["password"]):
            session.update(uid=u["id"], name=u["name"], role=u["role"])
            return redirect({"kitchen": "/kitchen", "admin": "/admin"}.get(u["role"], "/"))
        flash("Wrong email or password.", "err")
    return render_template("login.html")

@app.route("/register", methods=["POST"])
def register():
    try:
        q("insert into users(name,email,pw,role) values(?,?,?,?)", (request.form["name"], request.form["email"].strip().lower(),
          generate_password_hash(request.form["password"]), request.form["role"]), commit=True)
        flash("Account created. Please sign in.", "ok")
    except sqlite3.IntegrityError:
        flash("That email is already registered.", "err")
    return redirect(url_for("login"))

@app.route("/logout")
def logout(): session.clear(); return redirect(url_for("login"))

# ───────── Module 2 + 10: Menu display & Inventory ─────────
@app.route("/")
@login_required("student", "staff")
def menu():
    return render_template("menu.html", items=q("select * from items where active=1"))

# ───────── Module 5: Smart Slot Allocation ─────────
def slot_list(load):
    cap = int(q("select v from settings where k='cap'", one=True)["v"])
    today = datetime.now().strftime("%Y-%m-%d")
    t = datetime.now().replace(second=0, microsecond=0) + timedelta(minutes=10)
    t = t.replace(minute=t.minute // 10 * 10)
    out = []
    for i in range(12):
        s = (t + timedelta(minutes=10 * i)).strftime("%H:%M")
        used = q("""select coalesce(sum(oi.qty*m.prep),0) u from orders o join order_items oi on oi.order_id=o.id
                    join items m on m.id=oi.item_id where o.slot=? and o.day=? and o.status!='Collected'""", (s, today), one=True)["u"]
        out.append({"slot": s, "left": cap - used, "ok": cap - used >= load})
    return out

@app.route("/api/slots")
@login_required()
def api_slots():
    return jsonify(slot_list(int(request.args.get("load", 0))))

# ───────── Modules 3, 4, 9: Ordering, Pre-order, Payment ─────────
@app.route("/api/order", methods=["POST"])
@login_required("student", "staff")
def place_order():
    d = request.json; cart = {int(k): v for k, v in d["cart"].items() if v > 0}
    if not cart: return jsonify(error="Your cart is empty."), 400
    items = {i["id"]: i for i in q("select * from items where id in (%s)" % ",".join("?" * len(cart)), tuple(cart))}
    for iid, n in cart.items():
        if items[iid]["stock"] < n: return jsonify(error=f"Only {items[iid]['stock']} left of {items[iid]['name']}."), 400
    load = sum(items[i]["prep"] * n for i, n in cart.items())
    if not next((s for s in slot_list(load) if s["slot"] == d["slot"] and s["ok"]), None):
        return jsonify(error="That slot just filled up. Pick another."), 409
    today = datetime.now().strftime("%Y-%m-%d")
    token = q("select count(*)+1 c from orders where day=?", (today,), one=True)["c"]
    total = sum(items[i]["price"] * n for i, n in cart.items())
    oid = q("insert into orders(token,user_id,slot,day,total,method,paid,created) values(?,?,?,?,?,?,?,?)",
            (token, session["uid"], d["slot"], today, total, d["method"], 0 if d["method"] == "Cash" else 1,
             datetime.now().isoformat()), commit=True)
    for i, n in cart.items():
        q("insert into order_items values(?,?,?)", (oid, i, n), commit=True)
        q("update items set stock=stock-? where id=?", (n, i), commit=True)   # inventory update
    return jsonify(token=token, slot=d["slot"], total=total)

# ───────── Module 8: Live Order Tracking ─────────
@app.route("/track")
@login_required("student", "staff")
def track(): return render_template("track.html")

@app.route("/api/my")
@login_required()
def api_my():
    rows = q("select * from orders where user_id=? order by id desc limit 10", (session["uid"],))
    return jsonify([{**dict(r), "items": [dict(i) for i in q(
        "select m.name,oi.qty from order_items oi join items m on m.id=oi.item_id where order_id=?", (r["id"],))]} for r in rows])

# ───────── Module 6: Queue Management (public board) ─────────
@app.route("/queue")
def queue(): return render_template("queue.html")

@app.route("/api/queue")
def api_queue():
    today = datetime.now().strftime("%Y-%m-%d")
    rows = q("select token,slot,status from orders where day=? and status!='Collected' order by slot,id", (today,))
    return jsonify([dict(r) for r in rows])

# ───────── Module 7: Kitchen Dashboard ─────────
@app.route("/kitchen")
@login_required("kitchen", "admin")
def kitchen(): return render_template("kitchen.html")

@app.route("/api/kitchen")
@login_required("kitchen", "admin")
def api_kitchen():
    today = datetime.now().strftime("%Y-%m-%d")
    rows = q("select * from orders where day=? and status!='Collected' order by slot,id", (today,))
    return jsonify([{**dict(r), "items": [dict(i) for i in q(
        "select m.name,m.emoji,oi.qty from order_items oi join items m on m.id=oi.item_id where order_id=?", (r["id"],))]} for r in rows])

@app.route("/api/status/<int:oid>/<s>", methods=["POST"])
@login_required("kitchen", "admin")
def set_status(oid, s):
    if s in ("Pending", "Preparing", "Ready", "Collected"):
        q("update orders set status=? where id=?", (s, oid), commit=True)
        if s == "Collected": q("update orders set paid=1 where id=?", (oid,), commit=True)
    return jsonify(ok=True)

# ───────── Module 11: Admin Dashboard (menu, prices, stock, slots) ─────────
@app.route("/admin", methods=["GET", "POST"])
@login_required("admin")
def admin():
    if request.method == "POST":
        f = request.form; a = f["action"]
        if a == "add":
            q("insert into items(name,price,stock,prep,emoji) values(?,?,?,?,?)",
              (f["name"], f["price"], f["stock"], f["prep"], f["emoji"] or "🍽️"), commit=True)
        elif a == "save":
            q("update items set price=?,stock=?,prep=? where id=?", (f["price"], f["stock"], f["prep"], f["id"]), commit=True)
        elif a == "toggle":
            q("update items set active=1-active where id=?", (f["id"],), commit=True)
        elif a == "cap":
            q("update settings set v=? where k='cap'", (f["cap"],), commit=True)
        flash("Saved.", "ok"); return redirect("/admin")
    today = datetime.now().strftime("%Y-%m-%d")
    stats = q("select count(*) n, coalesce(sum(total),0) s from orders where day=?", (today,), one=True)
    return render_template("admin.html", items=q("select * from items"), stats=stats,
                           cap=q("select v from settings where k='cap'", one=True)["v"],
                           orders=q("select o.*,u.name uname from orders o join users u on u.id=o.user_id order by o.id desc limit 15"))

if __name__ == "__main__":
    init_db(); app.run(debug=True)

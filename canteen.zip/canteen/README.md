# CampusBite – Canteen Queue & Pre-Order
    pip install flask
    python app.py      # open http://127.0.0.1:5000
Demo logins: student@c.com/student · staff@c.com/staff · kitchen@c.com/kitchen · admin@c.com/admin
